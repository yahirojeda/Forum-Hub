INSERT INTO respuestas(id_topico, autor_respuesta, respuesta, fecha_creacion, estado)
VALUES
(1, 'Diego Sacarias','Incluiremos más práctica para que adquieran mayor confianza. Gracias por tu sugerencia.', '2025-01-16','ENVIADA')