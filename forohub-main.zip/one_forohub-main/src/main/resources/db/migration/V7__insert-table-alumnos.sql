INSERT INTO alumnos (nombre, email, matricula, nacionalidad, curso_actual, fecha_nacimiento,activo)
VALUES
( 'Claudia Alvarez', 'claudia.alvarez@example.com', '1001', 'Argentina', 'JAVA', '1995-03-15', true),
( 'Carlos Pérez', 'carlos.perez@example.com', '1002', 'México', 'REACT', '1998-07-20',true),
( 'Ana López', 'ana.lopez@example.com', '1003', 'Colombia', 'QA', '1993-11-10',true);
