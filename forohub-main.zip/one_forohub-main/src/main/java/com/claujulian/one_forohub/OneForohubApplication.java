package com.claujulian.one_forohub;

import com.claujulian.one_forohub.model.Topico;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneForohubApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneForohubApplication.class, args);
	}



}
