package com.claujulian.one_forohub.model;

public enum Categoria {
    SUGERENCIA,
    CONSULTA,
    ERROR
}
