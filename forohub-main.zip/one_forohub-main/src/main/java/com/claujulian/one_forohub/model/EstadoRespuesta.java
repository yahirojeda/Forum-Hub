package com.claujulian.one_forohub.model;

public enum EstadoRespuesta {
    ELIMINADA,
    ENVIADA
}
