package com.claujulian.one_forohub.dto.autenticacion;

public record DatosTokenJWT(String token) {
}
