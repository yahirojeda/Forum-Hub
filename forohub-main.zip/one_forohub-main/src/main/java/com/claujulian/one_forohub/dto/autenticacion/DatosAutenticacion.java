package com.claujulian.one_forohub.dto.autenticacion;

public record DatosAutenticacion(String login, String password) {
}
