package com.claujulian.one_forohub.model;

public enum Curso {
    JAVA,
    REACT,
    TESTING,
    QA,
    UX
}
