package com.claujulian.one_forohub.model;

public enum Estado {
    ELIMINADO,
    PENDIENTE,
    CONTESTADO
}
