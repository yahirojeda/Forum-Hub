package com.claujulian.one_forohub.infra.validaciones;

import com.claujulian.one_forohub.dto.topico.DatosRegistroTopico;

public interface ValidadorDeTopico{
    void validar(DatosRegistroTopico datos);

}
