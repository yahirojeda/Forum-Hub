package com.claujulian.one_forohub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneForohubApplicationTests {

	@Test
	void contextLoads() {
	}

}
